//
//  main.m
//  Bouncy Cloud
//
//  Created by Austin Lubetkin on Monday, October 3, 2016
//  Copyright (c) Austin Lubetkin. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
