//
//  AppDelegate.h
//  Bouncy Cloud
//
//  Created by Austin Lubetkin on Monday, October 3, 2016
//  Copyright (c) Austin Lubetkin. All rights reserved.
//

#import <UIKit/UIKit.h>

@class StandaloneCodeaViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) StandaloneCodeaViewController *viewController;

@end
