//
//  main.m
//  Bouncy Cloud
//
//  Created by Austin Lubetkin on Wednesday, July 22, 2015
//  Copyright (c) Austin Lubetkin. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
